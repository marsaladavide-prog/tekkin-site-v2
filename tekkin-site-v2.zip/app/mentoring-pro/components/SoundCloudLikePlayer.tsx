"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import WaveSurfer from "wavesurfer.js";
import {
  Play, Pause, SkipBack, SkipForward,
  Volume2, VolumeX, Repeat, Repeat1, Download, Upload
} from "lucide-react";

// Tipi commenti
type CommentMarker = {
  id: string;
  author: string;
  text: string;
  atSeconds: number;
  avatarUrl?: string;
};

interface PlayerProps {
  audioUrl: string;              // traccia iniziale
  artworkUrl?: string;
  title: string;
  artist: string;
  genre?: string;
  initialComments?: CommentMarker[];
  initialPlays?: number;
  initialLikes?: number;
  allowRateChange?: boolean;
  allowLoop?: boolean;
}

export default function SoundCloudLikePlayer({
  audioUrl,
  artworkUrl = "/images/your-art.jpg",
  title,
  artist,
  genre = "Minimal / Deep Tech",
  initialComments = [],
  allowRateChange = true,
  allowLoop = true,
}: PlayerProps) {
  const waveRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WaveSurfer | null>(null);

  // se l'utente carica un file, usiamo quello
  const [currentSrc, setCurrentSrc] = useState<string>(audioUrl);
  const objectUrlRef = useRef<string | null>(null); // per revocare URL locali

  const [ready, setReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [current, setCurrent] = useState(0);
  const [volume, setVolume] = useState(0.9);
  const [muted, setMuted] = useState(false);
  const [loop, setLoop] = useState(false);
  const [rate, setRate] = useState(1);
  const [selectedTime, setSelectedTime] = useState<number | null>(null);

  const [comments, setComments] = useState<CommentMarker[]>(initialComments);
  const [commentDraft, setCommentDraft] = useState("");

  // Inizializza WaveSurfer
  useEffect(() => {
    if (!waveRef.current) return;

    const ws = WaveSurfer.create({
      container: waveRef.current,
      height: 160,
      barWidth: 2,
      barGap: 2,
      barRadius: 2,
      waveColor: "#2a2f31",
      progressColor: "#43FFD2",
      cursorColor: "transparent",
      normalize: true,
      autoCenter: false,
      autoScroll: false,
      dragToSeek: true,
      url: currentSrc,
    });

    wsRef.current = ws;

    const onReady = () => {
      setDuration(ws.getDuration());
      setReady(true);
      ws.setVolume(volume);
      ws.setPlaybackRate(rate);
      setCurrent(0);
      setPlaying(false);
    };
    const onTime = () => setCurrent(ws.getCurrentTime());
    const onFinish = () => {
      setPlaying(false);
      if (loop) {
        ws.play(0);
        setPlaying(true);
      }
    };

    ws.on("ready", onReady);
    ws.on("decode", onReady);
    ws.on("audioprocess", onTime);
    ws.on("seek", onTime);
    ws.on("finish", onFinish);

    return () => {
      ws.un("ready", onReady);
      ws.un("decode", onReady);
      ws.un("audioprocess", onTime);
      ws.un("seek", onTime);
      ws.un("finish", onFinish);
      ws.destroy();
      wsRef.current = null;
      setReady(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentSrc, loop]);

  // pulizia objectURL quando cambia traccia caricata o unmount
  useEffect(() => {
    return () => {
      if (objectUrlRef.current) {
        URL.revokeObjectURL(objectUrlRef.current);
        objectUrlRef.current = null;
      }
    };
  }, []);

  // Comandi
  const togglePlay = useCallback(() => {
    const ws = wsRef.current;
    if (!ws || !ready) return;
    if (playing) {
      ws.pause();
      setPlaying(false);
    } else {
      ws.play();
      setPlaying(true);
    }
  }, [playing, ready]);

  const seekDelta = (delta: number) => {
    const ws = wsRef.current;
    if (!ws) return;
    const t = Math.min(Math.max(0, ws.getCurrentTime() + delta), duration);
    ws.setTime(t);
    setCurrent(t);
  };

  const toggleMute = () => {
    const ws = wsRef.current;
    if (!ws) return;
    if (muted) {
      ws.setVolume(volume);
      setMuted(false);
    } else {
      ws.setVolume(0);
      setMuted(true);
    }
  };

  const handleVolume = (v: number) => {
    const ws = wsRef.current;
    if (!ws) return;
    const x = Math.min(1, Math.max(0, v));
    ws.setVolume(x);
    setVolume(x);
    setMuted(x === 0);
  };

  const handleRate = (r: number) => {
    const ws = wsRef.current;
    if (!ws) return;
    setRate(r);
    ws.setPlaybackRate(r);
  };

  // Tastiera
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        e.preventDefault();
        togglePlay();
      }
      if (e.code === "ArrowRight") {
        e.preventDefault();
        seekDelta(5);
      }
      if (e.code === "ArrowLeft") {
        e.preventDefault();
        seekDelta(-5);
      }
      if (e.key.toLowerCase() === "m") {
        setSelectedTime(wsRef.current ? wsRef.current.getCurrentTime() : current);
      }
      if (e.key.toLowerCase() === "c") {
        const input = document.getElementById("comment-input") as HTMLInputElement | null;
        input?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [current, togglePlay]);

  // Click waveform per cercare o solo marcare
  const clickWave = (e: React.MouseEvent<HTMLDivElement>, setOnlyMarker = false) => {
    if (!waveRef.current || duration === 0) return;
    const rect = waveRef.current.getBoundingClientRect();
    const pct = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    const t = pct * duration;
    setSelectedTime(t);
    if (!setOnlyMarker) {
      const ws = wsRef.current;
      if (ws) {
        ws.setTime(t);
        setCurrent(t);
      }
    }
  };

  // Upload
  const onUpload = (files?: FileList | null) => {
    if (!files || files.length === 0) return;
    const f = files[0];
    const url = URL.createObjectURL(f);
    // libera precedente objectURL se presente
    if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    objectUrlRef.current = url;
    setCurrentSrc(url);
    setComments([]); // reset commenti per nuova traccia locale
    setSelectedTime(null);
  };

  // Commenti
  const fmt = useCallback((t: number) => {
    if (!isFinite(t)) return "0:00";
    const m = Math.floor(t / 60);
    const s = Math.floor(t % 60);
    return `${m}:${s.toString().padStart(2, "0")}`;
  }, []);

  const addComment = () => {
    const text = commentDraft.trim();
    if (!text) return;
    const at = selectedTime !== null ? selectedTime : current;
    const c: CommentMarker = { id: `${Date.now()}`, author: "You", text, atSeconds: at };
    const updated = [...comments, c].sort((a, b) => a.atSeconds - b.atSeconds);
    setComments(updated);
    setCommentDraft("");
  };

  const removeComment = (id: string) => {
    setComments(prev => prev.filter(c => c.id !== id));
  };

  const currentPct = useMemo(
    () => (duration > 0 ? current / duration : 0),
    [current, duration]
  );

  return (
    <div className="w-full rounded-2xl border border-[#111718] bg-[#0a0e0f] text-zinc-100 overflow-hidden shadow-[0_0_24px_rgba(67,255,210,0.08)]">
      {/* Header professionale */}
      <div className="flex items-center gap-4 p-4">
        <div className="h-14 w-14 overflow-hidden rounded-md bg-[#121718] ring-1 ring-[#1c2628]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={artworkUrl} alt={title} className="h-full w-full object-cover" />
        </div>
        <div className="min-w-0">
          <div className="text-[12px] text-[#8feedd] truncate">
            {artist} • {genre}
          </div>
          <div className="truncate font-semibold">{title}</div>
        </div>

        <div className="ml-auto flex items-center gap-2">
          {/* Upload button */}
          <label className="inline-flex items-center gap-2 rounded-md border border-[#1c2628] bg-[#0f1516] px-3 py-2 hover:bg-[#121a1b] cursor-pointer text-sm">
            <Upload size={16} />
            <span>Upload</span>
            <input type="file" accept="audio/*" className="hidden" onChange={(e) => onUpload(e.target.files)} />
          </label>

          {/* Download corrente */}
          <a
            href={currentSrc}
            download={title.replace(/\s+/g, "_") + ".wav"}
            className="inline-flex items-center gap-2 rounded-md border border-[#1c2628] bg-[#0f1516] px-3 py-2 hover:bg-[#121a1b] text-sm"
            title="Download"
          >
            <Download size={16} />
            Download
          </a>
        </div>
      </div>

      {/* Waveform full-width con background sotto */}
      <div
        className="relative px-4 pb-2 select-none"
        onClick={(e) => clickWave(e, false)}
        onContextMenu={(e) => { e.preventDefault(); clickWave(e, true); }}
      >
        <div ref={waveRef} className="w-full relative z-[2] h-[160px]" />

        {/* Background pulito e professionale sotto la wave */}
        <div className="pointer-events-none absolute inset-0 z-[1]">
          {/* scanlines leggere */}
          <div className="absolute inset-0 opacity-[0.06] [background:repeating-linear-gradient(0deg,transparent,transparent_2px,#000_3px)]" />
          {/* grana fine */}
          <div className="absolute inset-0 opacity-[0.05] [background-image:radial-gradient(rgba(255,255,255,0.08)_1px,transparent_1px)] [background-size:3px_3px]" />
          {/* vignetta */}
          <div className="absolute inset-0 bg-[radial-gradient(transparent_65%,rgba(10,16,17,0.55))]" />
        </div>

        {/* progress highlight elegante */}
        <div
          className="pointer-events-none absolute left-0 top-0 bottom-0 z-[2]"
          style={{
            width: `${currentPct * 100}%`,
            background:
              "linear-gradient(90deg, rgba(67,255,210,0.20), rgba(0,255,255,0.10))",
            mixBlendMode: "screen",
          }}
        />

        {/* markers commenti */}
        {duration > 0 &&
          comments.map((c) => {
            const pct = Math.min(1, Math.max(0, c.atSeconds / duration));
            return (
              <button
                key={c.id}
                title={`${c.author}: ${c.text}`}
                className="absolute top-2 -translate-x-1/2 z-[3]"
                style={{ left: `${pct * 100}%` }}
                onClick={(e) => {
                  e.stopPropagation();
                  const ws = wsRef.current;
                  if (!ws) return;
                  ws.setTime(c.atSeconds);
                  setCurrent(c.atSeconds);
                  setSelectedTime(c.atSeconds);
                }}
              >
                <div className="h-3 w-[2px] bg-[#8feedd] shadow-[0_0_8px_rgba(67,255,210,0.5)]" />
              </button>
            );
          })}
      </div>

      {/* Barra controlli in basso, stile DAW pro */}
      <div className="flex flex-wrap items-center gap-3 px-4 pb-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => seekDelta(-5)}
            className="rounded-md bg-[#0f1516] p-2 border border-[#1c2628] hover:bg-[#121a1b]"
            title="-5s"
          >
            <SkipBack size={16} />
          </button>
          <button
            onClick={togglePlay}
            className="flex items-center gap-2 rounded-md bg-[#43FFD2] px-4 py-2 text-black font-medium hover:brightness-110 active:scale-[0.98]"
            title={playing ? "Pause" : "Play"}
          >
            {playing ? <Pause size={16} /> : <Play size={16} />}
            {playing ? "Pause" : "Play"}
          </button>
          <button
            onClick={() => seekDelta(5)}
            className="rounded-md bg-[#0f1516] p-2 border border-[#1c2628] hover:bg-[#121a1b]"
            title="+5s"
          >
            <SkipForward size={16} />
          </button>
        </div>

        <div className="rounded bg-[#0f1516] px-2 py-1 border border-[#1c2628] text-xs">
          {isFinite(current) ? `${fmt(current)} / ${fmt(duration)}` : "0:00 / 0:00"}
        </div>

        {allowLoop && (
          <button
            onClick={() => setLoop(v => !v)}
            className={`rounded-md p-2 border ${
              loop ? "bg-[#43FFD2] text-black border-[#43FFD2]" : "bg-[#0f1516] hover:bg-[#121a1b] border-[#1c2628]"
            }`}
            title="Loop"
          >
            {loop ? <Repeat1 size={16} /> : <Repeat size={16} />}
          </button>
        )}

        <div className="ml-auto flex items-center gap-3">
          <div className="flex items-center gap-2">
            <button onClick={toggleMute} className="rounded p-1.5 hover:bg-[#0f1516] border border-[#1c2628]">
              {muted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={muted ? 0 : volume}
              onChange={(e) => handleVolume(parseFloat(e.target.value))}
              className="w-32 accent-[#43FFD2]"
              aria-label="Volume"
            />
          </div>

          {allowRateChange && (
            <select
              value={rate}
              onChange={(e) => handleRate(parseFloat(e.target.value))}
              className="rounded border border-[#1c2628] bg-[#0f1516] px-2 py-1 text-sm"
              aria-label="Playback speed"
            >
              <option value={0.75}>0.75x</option>
              <option value={0.9}>0.90x</option>
              <option value={1}>1.00x</option>
              <option value={1.1}>1.10x</option>
              <option value={1.25}>1.25x</option>
              <option value={1.5}>1.50x</option>
            </select>
          )}
        </div>
      </div>

      {/* Commenti */}
      <div className="border-t border-[#121718] px-4 pb-4">
        <div className="flex items-center gap-2 pt-3">
          <div className="rounded-full bg-[#0f1516] h-8 w-8 border border-[#1c2628]" />
          <input
            id="comment-input"
            value={commentDraft}
            onChange={(e) => setCommentDraft(e.target.value)}
            placeholder={`Commenta a ${fmt(selectedTime ?? current)}`}
            className="flex-1 rounded border border-[#1c2628] bg-[#0f1516] px-3 py-2 outline-none focus:border-[#43FFD2]"
            onKeyDown={(e) => { if (e.key === "Enter") addComment(); }}
          />
          <button
            onClick={addComment}
            className="inline-flex items-center gap-2 rounded-md bg-[#43FFD2] px-3 py-2 text-black hover:brightness-110"
          >
            Aggiungi
          </button>
        </div>

        {comments.length > 0 && (
          <div className="mt-3 max-h-48 space-y-2 overflow-y-auto pr-1">
            {comments.map((c) => (
              <div key={c.id} className="flex items-start gap-2 text-sm">
                <div className="rounded-full bg-[#0f1516] h-7 w-7 border border-[#1c2628]" />
                <div className="flex-1">
                  <div className="text-[#a9e9dd]">
                    <span className="font-medium text-zinc-200">{c.author}</span>
                    <button
                      className="ml-2 rounded bg-[#0f1516] px-2 py-[2px] text-[11px] text-[#8feedd] border border-[#1c2628] hover:bg-[#121a1b]"
                      onClick={() => {
                        const ws = wsRef.current;
                        if (!ws) return;
                        ws.setTime(c.atSeconds);
                        setCurrent(c.atSeconds);
                        setSelectedTime(c.atSeconds);
                      }}
                      title="Vai al punto"
                    >
                      {fmt(c.atSeconds)}
                    </button>
                  </div>
                  <div className="text-zinc-100">{c.text}</div>
                </div>
                <button
                  className="rounded p-1 text-zinc-400 hover:text-zinc-200"
                  onClick={() => removeComment(c.id)}
                  title="Elimina"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
